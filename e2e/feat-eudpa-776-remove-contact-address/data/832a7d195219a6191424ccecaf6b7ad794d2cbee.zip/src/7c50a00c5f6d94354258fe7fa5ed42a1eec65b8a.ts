import { test, expect } from '@fixtures';
import { uniquelyNamedCommercialTransporter } from '@domain/animals/constants/transporters';

test.describe('Commercial transporter journeys', () => {
  test(
    'a trader can submit a notification using a hand-added commercial transporter',
    { tag: '@cross-browser' },
    async ({ animalsSeededJourney, animalsJourney, pages, animalsPages }) => {
      const referenceNumber = await animalsSeededJourney.createDraftNotification('partial');
      await animalsSeededJourney.resumeInUi(referenceNumber, animalsPages.transitedCountries);

      await animalsPages.transitedCountries.addCountry('France');
      await animalsPages.transitedCountries.addCountry('Belgium');
      await animalsPages.transitedCountries.saveAndReturnToOverview.click();

      await animalsPages.overview.heading.waitFor();
      await animalsPages.overview.task('Transport details').click();
      await animalsPages.transporter.heading.waitFor();
      await animalsPages.transporter.addTransporter.click();
      await animalsPages.transporterAdd.heading.waitFor();
      await animalsPages.transporterAdd.transporterType('Commercial').check();
      await animalsPages.transporterAdd.continueButton.click();
      await animalsPages.commercialTransporter.heading.waitFor();
      await animalsJourney.fillAndSaveCommercialTransporterAddFormToOverview(uniquelyNamedCommercialTransporter());

      await animalsPages.overview.task('Contact address for this consignment').click();
      await animalsPages.contactAddress.address('Animal and Plant Health Agency').check();
      await animalsPages.contactAddress.saveAndReturnToOverview.click();
      await animalsPages.overview.heading.waitFor();

      await animalsJourney.openReviewFromOverview();
      await animalsPages.notificationView.continueButton.click();
      await animalsPages.declaration.heading.waitFor();
      await animalsPages.declaration.confirmation.check();
      await animalsPages.declaration.continueButton.click();

      await expect(pages.page.getByRole('heading', { name: 'Import notification submitted' })).toBeVisible();
    },
  );
});
